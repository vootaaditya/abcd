import { combineReducers } from "redux";
import teamReducers from "../components/FavouriteTeams/reducers"

const combinedReducer = combineReducers({
    teamReducers
});

export default combinedReducer;
