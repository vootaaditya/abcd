import React from 'react';

const Sample = () => (
  <div>
    test
  </div>
);

export default Sample;
