import React from 'react';
import dog from '../images/dog.png';
import FavouriteTeams from './FavouriteTeams/index.js'

const About = () => (
  <div>
    Hello
    
    <h1>Welcome to react project</h1>
    < FavouriteTeams/>
  </div>
);

export default About;
