const Init={
teams:[],
teamLocations:[]
}
export default function teamReducer(state =Init, action) {
    switch (action.type) {
            case "GET_TEAMLOCATION":
            return Object.assign({}, state, {teams:action.payload});
            case "GET_TEAMLOCATIONDETAILS":
            return Object.assign({}, state,{teamLocations: action.payload})
        default:
            return state;
    }
}