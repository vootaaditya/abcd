import React from "react";

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from "react-router-dom";
import * as actions from './actions.js';


class Teams extends React.Component {

    componentDidMount(){
        this.props.actions.fetchTeamlocation()
    }

    render() {
        return(
            <div className="container">
                <div className="status_bar"></div>
                    <div className="title_bar">
                       
                        <p>PICK FAVOURITE TEAMS</p>
                    </div>
                    <ul className="team_list">
                        {this.props.locations && this.props.locations.map((item, index) => {
                            return <li key = {index}><Link to="/details" className="link"><span className="icon"></span>{item.name}</Link></li>
                        })}
                    </ul>
                <div className="btnContainer">
                    <button>Done</button>
                </div>
            </div>
        );
    }
}

    function mapStateToProps(state, ownProps) {
        return {
            locations: state.teamReducers.teams
        }
    }
    
    function mapDispatchToProps(dispatch) {
        return {
            actions: bindActionCreators(actions, dispatch)
        }
    }
    
    export default connect(mapStateToProps, mapDispatchToProps)(Teams);