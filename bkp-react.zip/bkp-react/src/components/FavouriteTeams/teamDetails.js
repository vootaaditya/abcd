import React from "react";
import { connect } from 'react-redux';

import { bindActionCreators } from 'redux';
import * as commissionsSummaryActions from './actions.js';
import './style.css';
import {Link } from "react-router-dom";

class TeamDetails extends React.Component {
    componentDidMount(){
        this.props.actions.fetchTeamLocationDetails()
    }

    render() {
        return(
            <div className="container">
                <div className="status_bar"></div>
                <div className="title_bar">
                    <Link to="/">  </Link>
                    <p>PICK FAVOURITE TEAMS</p>
                </div>
                <ul className="team_list">
                    { this.props.location && this.props.location.map((item, index) => {
                        return <li key = {index}><span className="icon"></span>{item.username}<input type="checkbox" className="checkbox" /></li>
                    })}
                </ul>
            </div>
        );
    }
}

function mapStateToProps(state, ownProps) {debugger;
    return {
        location: state.teamReducers.teamLocations
    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(commissionsSummaryActions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TeamDetails);